//
//  ContentView.swift
//  ToDoList
//
//  Created by Cindy Huynh on 12/27/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack{
            Color(red: 0, green: 0.5, blue: 0).ignoresSafeArea()
        
        VStack {
            Image("logo").resizable().aspectRatio(contentMode: .fit).scaleEffect(/*@START_MENU_TOKEN@*/0.5/*@END_MENU_TOKEN@*/)
            Spacer()
            Spacer()
            
            HStack {
                Spacer()
                Image("card-3").resizable().aspectRatio(contentMode: .fit).scaleEffect(0.7)
                Spacer()
                Image("card-4").resizable().aspectRatio(contentMode: .fit).scaleEffect(0.7)
                Spacer()
            }
            Spacer()
            Image("deal-button").resizable().aspectRatio(contentMode: .fit).padding().scaleEffect(0.25)
            Spacer()
            
            HStack{
                Spacer()
                VStack {
                    Text("Player").foregroundColor(.white).padding(.bottom)
                        
                    
                    Text("0").foregroundColor(.white).bold().font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                }.padding(.trailing)
                Spacer()
                VStack {
                    Text("CPU").foregroundColor(.white)
                        .padding(.bottom)
                    
                    Text("0").foregroundColor(.white).bold().font(.title)
                }.padding(.leading)
                Spacer()
            }
            Spacer()
        }
    }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
