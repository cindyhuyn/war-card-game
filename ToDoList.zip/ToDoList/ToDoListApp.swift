//
//  ToDoListApp.swift
//  ToDoList
//
//  Created by Cindy Huynh on 12/27/22.
//

import SwiftUI

@main
struct ToDoListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
